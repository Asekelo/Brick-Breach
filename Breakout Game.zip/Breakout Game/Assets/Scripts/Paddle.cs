﻿using System.Collections;
using UnityEngine;

public class Paddle : MonoBehaviour {

    public float paddleSpeed = 1f;
    public bool mouseControl = true;
    private Vector3 playerPos = new Vector3(0, -9.5f, 0); //x = 0, y = -9.5, z = 0
    bool mouseMoves;

    public void Start()
    {
        Cursor.visible = false; //the mouse does not show
        transform.position = playerPos; //the paddle starts in the bottom positon
    }


    // Update is called once per frame
    public void Update()
    {
        if (Input.GetAxis("Mouse X") != 0)//if the mouse moves
        {
            mouseMoves = mouseControl;
            float xPos = transform.position.x + Input.GetAxis("Mouse X") * paddleSpeed;
            playerPos = new Vector3(Mathf.Clamp(xPos, -8f, 8f), -9.5f, 0f);
            transform.position = playerPos;

        }
        else if (Input.GetAxis("Horizontal") != 0 && !mouseMoves)//else if the mouse doesn't move && the horizontal arrow keys are pressed
        {
            float xPos = transform.position.x + (Input.GetAxis("Horizontal") * paddleSpeed);
            playerPos = new Vector3(Mathf.Clamp(xPos, -8f, 8f), -9.5f, 0f);//Limit how far the paddle can move along the x-axis
            transform.position = playerPos;
        }
        else {
            mouseMoves = false;
        }
    }
}
