﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class GM : MonoBehaviour
{
    public int lives = 3;
    public int bricks = 24;
    public float resetDelay = 1f;
    public float timeLeft = 60.0f;
    public Text timeText;
    public Text livesText;
    public GameObject gameOver;
    public GameObject youWon;
    public GameObject brickPrefab;
    public GameObject paddle;
    public GameObject deathParticles;
    public static GM instance = null;

    private GameObject clonePaddle;

    // Start is called before the first frame update
    void Awake()
    {
        if (instance == null)
            instance = this;//if there is no game manager, make this the game manager
        else if (instance != this)
            Destroy(gameObject);//else if there is already a game manager, destroy this one

        Setup();
    }

    public void Setup() {
        clonePaddle = Instantiate(paddle, transform.position, Quaternion.identity) as GameObject;
        Instantiate(brickPrefab, transform.position, Quaternion.identity);
    }

    void CheckGameOver() {
        if(bricks < 1)
        {
            youWon.SetActive(true);
            Time.timeScale = .25f;
            Invoke("Reset", resetDelay);
        }

        if (lives < 1)
        {
            gameOver.SetActive(true);
            Time.timeScale = .25f;
            Invoke("Reset", resetDelay);
        }
        if (timeLeft < 1)
        {
            gameOver.SetActive(true);
            Invoke("Reset", resetDelay);
        }
    }

    void Reset()
    {
        Time.timeScale = 1f;
        Application.LoadLevel(Application.loadedLevel);
    }

    public void LoseLife() {
        lives--;
        livesText.text = "Lives: " + lives;
        Instantiate(deathParticles, clonePaddle.transform.position, Quaternion.identity);
        Destroy(clonePaddle);
        Invoke("SetupPaddle", resetDelay);
        CheckGameOver();
    }

    void SetupPaddle()
    {
        clonePaddle = Instantiate(paddle, transform.position, Quaternion.identity) as GameObject; 
    }

    public void DestroyBrick() {
        bricks--;
        CheckGameOver();
    }

    void Update() {
        timeLeft -= Time.deltaTime;
        timeText.text = "Time: " + Mathf.Round(timeLeft);
        CheckGameOver();
    }

}
