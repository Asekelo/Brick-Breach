﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Audio1 : MonoBehaviour
{
    public AudioClip MusiClip;
    public AudioSource MusicSrc;

    // Start is called before the first frame update
    void Start()
    {
        MusicSrc.clip = MusiClip;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            MusicSrc.Play();
    }
}
