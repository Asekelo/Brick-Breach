﻿using System.Collections;
using UnityEngine;

public class DeadZone : MonoBehaviour
{
    public void OnTriggerEnter()
    {
        GM.instance.LoseLife();
    }
}
